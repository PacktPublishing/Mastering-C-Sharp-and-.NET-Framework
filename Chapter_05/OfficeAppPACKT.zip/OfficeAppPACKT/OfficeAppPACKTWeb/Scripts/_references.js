﻿/// <reference path="jquery-1.9.1.js" />
/* Required to correctly initalize Office.js for intellisense */
/// <reference path="_officeintellisense.js" />
/* Use offline copy of Office.js for intellisense */
// /// <reference path="office/1/outlook-win32.debug.js" />
// /// <reference path="office/1/office.js" />
/* Use online copy of Office.js for intellisense */
/// <reference path="https://appsforoffice.microsoft.com/lib/1/hosted/outlook-win32.debug.js" />
/// <reference path="https://appsforoffice.microsoft.com/lib/1/hosted/office.js" />
